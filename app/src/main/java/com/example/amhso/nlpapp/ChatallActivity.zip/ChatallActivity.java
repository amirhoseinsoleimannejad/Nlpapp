package com.example.amhso.nlpapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.example.amhso.nlpapp.otherclass.MessageAdapter;
import com.example.amhso.nlpapp.otherclass.message;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

//public class ChatallActivity extends AppCompatActivity {
//
//
//    private ListView listView;
//
//
//    private List<message> listmessage;
//    private MessageAdapter messageAdapter;
//
//    public static final int VOICE_RECOGNITION_REQUEST_CODE = 1234;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_chatall);
//
//
//
//        G.activity=this;
//
//
//        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
//        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
//                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
//        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
//                "Speech recognition demo");
//        startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);
//
//
//        listView=(ListView) findViewById(R.id.list_message);
//        listmessage = new ArrayList<message>();
//
//
//
////        HttpPostAsyncTask task = new HttpPostAsyncTask();
////        task.execute(G.urlserver + "fetch_message_all");
//
//
//
//    }
//
//
//
//
//
//
//
//
//
//
//
//
//    public class HttpPostAsyncTask extends AsyncTask<String, String, String> {
//
//
//        HttpPost httppost;
//        HttpClient httpclient;
//        List<NameValuePair> nameValuePairs;
//        public ProgressDialog progressDialog;
//
//
//
//
//
//
//        @Override
//        protected void onPostExecute(String result) {
//
//            Log.i("22222222222222222", "22222222222222222222222222" + result);
//
//            progressDialog.dismiss();
//            listmessage.clear();
//
//
//            try {
//
//
//                JSONArray contacts;
//                JSONObject jsonObj = new JSONObject(result);
//                contacts = jsonObj.getJSONArray("message_all");
//
//
//
//                for (int i = 0; i < contacts.length(); i++) {
//
//                    JSONObject c = contacts.getJSONObject(i);
//                    String text = c.getString("text");
//                    String date = c.getString("date");
//                    String time = c.getString("time");
//                    String image = c.getString("img");
//                    String id_user = c.getString("id_user");
//
//
//                    if (id_user.equals("7")){
//                        message m=new message(text,date,time,true,image);
//                        listmessage.add(m);
//
//                    }
//                    else{
//                        message m=new message(text,date,time,false,image);
//                        listmessage.add(m);
//
//                    }
//
////                    Log.i("eeeeeeeeeeeeeeeeeeeeee", "wwwwwww: "+m.getText());
//
//
//                }
//
//                messageAdapter = new MessageAdapter(G.activity,listmessage);
//                listView.setAdapter(messageAdapter);
//
//            }
//            catch (Exception e){
//
//
//                Log.i("eeeeee", "errrrrrrrror: "+e.toString());
//            }
//
//        }
//
//
//
//
//
//
//        @Override
//        protected void onPreExecute() {
//
//            try {
//                progressDialog = new ProgressDialog(G.activity);
//                progressDialog.setMessage("چند لحظه صبر کنید...."); // Setting Message
//                progressDialog.setTitle("در حال گرفتن پیام ها شما"); // Setting Title
//                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
//                progressDialog.show(); // Display Progress Dialog
//
//
//                new Thread(new Runnable() {
//                    public void run() {
//                        try {
//                            Thread.sleep(20000);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                        progressDialog.dismiss();
//                    }
//                }).start();
//
//
//            }
//            catch (Exception e){
//
//            }
//        }
//
//
//
//        // This is a function that we are overriding from AsyncTask. It takes Strings as parameters because that is what we defined for the parameters of our async task
//        @Override
//        protected String doInBackground(String... params) {
//
//            try {
//
//
//                Log.i("urluuuuuuuuuuuuuuu", "doInBackground: "+params[0]);
//
//                httpclient=new DefaultHttpClient();
//                httppost= new HttpPost(params[0]); // make sure the url is correct.
//                //add your data
//
//                Log.i("uuuuuu", "urluuuuuuuuuuuu "+params[0]);
//                nameValuePairs = new ArrayList<NameValuePair>(2);
//
//
//
////                Log.i("dddddddddd", "doInBackground: "+shpref.getString("id_user","-1").trim());
//                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs,"utf-8"));
//
//                ResponseHandler<String> responseHandler = new BasicResponseHandler();
//                String response = httpclient.execute(httppost, responseHandler);
//                System.out.println("Response : " + response);
//                return response;
//
//
//
//            } catch (Exception e) {
//                Log.i("error rrrrrrr", e.toString());
//            }
//
//            return "0";
//        }
//    }
//}






import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.speech.RecognizerIntent;
import android.support.v4.app.NavUtils;

public class ChatallActivity extends Activity implements OnClickListener {

    public ListView mList;
    public Button speakButton;

    public static final int VOICE_RECOGNITION_REQUEST_CODE = 1234;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatall);

        speakButton = (Button) findViewById(R.id.btn_speak);
        speakButton.setOnClickListener(this);

        voiceinputbuttons();
    }

    public void informationMenu() {
        startActivity(new Intent("android.intent.action.INFOSCREEN"));
    }

    public void voiceinputbuttons() {
        speakButton = (Button) findViewById(R.id.btn_speak);
        mList = (ListView) findViewById(R.id.list);
    }

    public void startVoiceRecognitionActivity() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                "Speech recognition demo");
        startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);
    }

    public void onClick(View v) {
        // TODO Auto-generated method stub
        startVoiceRecognitionActivity();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == VOICE_RECOGNITION_REQUEST_CODE && resultCode == RESULT_OK) {
            // Fill the list view with the strings the recognizer thought it
            // could have heard
            ArrayList matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            mList.setAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1, matches));
            // matches is the result of voice input. It is a list of what the
            // user possibly said.
            // Using an if statement for the keyword you want to use allows the
            // use of any activity if keywords match
            // it is possible to set up multiple keywords to use the same
            // activity so more than one word will allow the user
            // to use the activity (makes it so the user doesn't have to
            // memorize words from a list)
            // to use an activity from the voice input information simply use
            // the following format;
            // if (matches.contains("keyword here") { startActivity(new
            // Intent("name.of.manifest.ACTIVITY")

            if (matches.contains("information")) {
                informationMenu();
            }
        }
    }

}